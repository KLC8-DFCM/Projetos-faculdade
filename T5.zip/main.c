#include <stdio.h>
#include <stdlib.h>
#include <time.h>

typedef struct pecas
{
	int peca;
	unsigned int estado : 2; 
} pca;

typedef struct players
{
	char nome[20];
	int pontos;
	pca *pecas[6];
	int jogcol[6];
	int joglin[6];
} PLAYER;

pca pc[108]; 

void LimpaBuffer()
{
	char c;
	while ((c = getchar()) != '\n' && c != EOF)
		;
}

int tradutor(char input[2]){
	int jogada=0;

	switch(input[0]){

		case 'A':
		{
			jogada+=10;
			break;
		}

		case 'B':
		{
			jogada+=20;
			break;
		}

		case 'C':
		{
			jogada+=30;
			break;
		}

		case 'D':
		{
			jogada+=40;
			break;
		}

		case 'E':
		{
			jogada+=50;
			break;
		}

		case 'F':
		{
			jogada+=60;
			break;
		}

		default :
		{	
			printf("Escolha uma letra valida (maiusculas apenas):\n");
			return 0;
		}
	}

		switch(input[1]){

		case '1':
		{
			jogada+=1;
			break;
		}

		case '2':
		{
			jogada+=2;
			break;
		}

		case '3':
		{
			jogada+=3;
			break;
		}

		case '4':
		{
			jogada+=4;
			break;
		}

		case '5':
		{
			jogada+=5;
			break;
		}

		case '6':
		{
			jogada+=6;
			break;
		}

		default :
		{	
			printf("Escolha um numero valida (1-6):\n");
			return 0;
		}
	}
		int acu=0;
		for(int i=0;i<3;i++){
			if(pc[i*36 + (jogada/10 - 1)*6 + (jogada%10 - 1)].estado == 2 ){
				acu++;
			}
		}

		if(acu == 3){
			printf("Todas as pecas desse tipo estao no tabuleiro\n");
			return 0;
		}


	return jogada;
}

void tablinha(int ***tab, int imax, int jmax, int tipo)
{ // tipo == 0 caso limite das linhas seja acima, 1 caso abaixo
	int i, j;
	if (tipo == 0)
	{
		int **temp;
		temp = (int **)malloc(sizeof(int *) * (imax + 1));
		if (!temp)
		{
			printf("Erro de alocacao\n");
			exit(1);
		}
		for (i = 0; i < (imax + 1); i++)
		{
			temp[i] = (int *)malloc(sizeof(int) * jmax);
			if (!(temp[i]))
			{
				printf("Erro de alocacao\n");
				exit(1);
			}
		}

		for (i = 0; i < (imax + 1); i++)
		{

			for (j = 0; j < jmax; j++)
			{
				if (i == 0)
				{
					temp[i][j] = 0;
				}
				else
				{
					temp[i][j] = ((*tab)[i - 1])[j];
				}
			}
		}

		(*tab) = (int **)realloc((*tab), sizeof(int *) * (imax + 1));
		if (!(*tab))
		{
			printf("Erro de alocacao\n");
			exit(1);
		}
		(*tab)[imax] = (int *)malloc(sizeof(int) * jmax);
		if (!(*tab))
		{
			printf("Erro de alocacao\n");
			exit(1);
		}

		*tab = temp;
	}
	else
	{
		(*tab) = (int **)realloc(*tab, sizeof(int *) * (imax + 1));
		if (!(*tab))
		{
			printf("Erro de alocacao\n");
			exit(1);
		}
		(*tab)[imax] = (int *)malloc(sizeof(int) * jmax);
		if (!(*tab))
		{
			printf("Erro de alocacao\n");
			exit(1);
		}

		for (j = 0; j < jmax; j++)
		{
			((*tab)[imax])[j] = 0;
		}
	}
}

void tabcoluna(int ***tab, int imax, int jmax, int tipo)
{ // tipo == 0 caso limite das colunas seja a esquerda, 1 caso a direita
	int i, j;
	if (tipo == 0)
	{
		int **temp;
		temp = (int **)malloc(sizeof(int **) * imax);
		if (!temp)
		{
			printf("Erro de alocacao\n");
			exit(1);
		}
		for (i = 0; i < imax; i++)
		{
			temp[i] = (int *)malloc(sizeof(int) * (jmax + 1));
			if (!(temp[i]))
			{
				printf("Erro de alocacao\n");
				exit(1);
			}
		}

		for (i = 0; i < imax; i++)
		{
			for (j = 0; j < (jmax + 1); j++)
			{
				if (j == 0)
				{
					temp[i][j] = 0;
				}
				else
				{
					temp[i][j] = ((*tab)[i])[j - 1];
				}
			}
		}

		for (i = 0; i < imax; i++)
		{
			(*tab)[i] = (int *)realloc((*tab)[i], sizeof(int) * (jmax + 1));
			if (!((*tab)[i]))
			{
				printf("Erro de alocacao\n");
				exit(1);
			}
		}

		*tab = temp;
	}
	else
	{
		for (i = 0; i < imax; i++)
		{
			(*tab)[i] = (int *)realloc((*tab)[i], sizeof(int) * (jmax + 1));
			if (!((*tab)[i]))
			{
				printf("Erro de alocacao\n");
				exit(1);
			}
		}
		for (i = 0; i < imax; i++)
		{
			((*tab)[i])[jmax] = 0;
		}
	}
}

void tabela(int **tab, int imax, int jmax)
{
	int i, j;
	char letras[7] = "[ABCDEF";
	printf("X");
	for (i = -1; i < imax; i++)
	{
		if (i != -1)
		{
			printf("%d ", i);
		}
		for (j = 0; j < jmax; j++)
		{
			if (i == -1)
			{
				printf("%3d", j);
			}
			else
			{
				int letra = tab[i][j] / 10;
				int nm = tab[i][j] % 10;
				printf("%c", letras[letra]);
				if (letra == 0)
				{
					printf(" ]");
				}
				else
				{
					printf("%d ", nm);
				}
			}
		}
		printf("\n");
	}
}

int sacola(PLAYER *P,int peca){//retorna 0->fim das pecas na sacola, 1-> ok
	if (peca == 0){//modo I

		srand(time(NULL));
		int aleatorios[6];

		for(int i=0;i<6;i++){
			int flag =1;
			aleatorios[i]= rand()% 108 ;

			if( pc[aleatorios[i]].estado != 0 ){
				i--;
				flag =0;
			}else{
			flag=1;
			}

			if(flag == 1 && i>=1){
				for(int j=i-1;j>=0;j--){
					if(aleatorios[i] == aleatorios[j]){
						i--;
						break;
					}
				}
			}

		}

		for(int i=0;i<6;i++){
	    	P->pecas[i] = &(pc[aleatorios[i]]);
			pc[aleatorios[i]].estado =1;
			P->jogcol[i]=-1;
			P->joglin[i]=-1;
			P->pontos=0;
		}

	}else{
		//modo T
		srand(time(NULL));
		int flag =1;
		int aleatorio;
		int count=0;
		do{
			aleatorio = rand()% 108 ;
	
			if( pc[aleatorio].estado != 0 ){
				flag =0;
			}else{
				flag=1;
			}

			count++;
			if(count == 108){
				printf("Sacola vazia\n");
				return 0;
			}
		}while(flag == 0);
		pc[aleatorio].estado = 1;

		P->pecas[peca-1]=&(pc[aleatorio]);

	}
	return 1;
}

int tipo(int elem1,int elem2){

	if(elem1 == 0 || elem2 == 0){
		return 0;//vazio 
	}else{	

		if(elem1%10 == elem2%10){
		return 1;//num igual
		}

		if(elem1/10 == elem2/10){
		return 2;//letra igual
		}

	}
	return 3;//nada igual

}

int auxiliar(int **tab,int lin,int col,int limite,int alc,int jogada,int parametro){

	if(alc < 2){

		if(parametro == 2 || parametro == -2){
			if(lin + parametro/2 >= 0 && lin + parametro/2 < limite){
			return tipo(jogada,tab[lin + parametro/2][col]);
			}else{
				return 0;
			}
		}else{
			if(col + parametro >=0 && col + parametro <limite){
			return tipo(jogada,tab[lin][col + parametro]);
			}else{
				return 0;
			}
		}

	}else{

	    if(parametro == 2 || parametro == -2){

    		if(tipo(jogada,tab[lin + parametro/2][col]) == 3){
				return 3;
		    }else{
				if(lin + parametro == limite || lin + parametro == -1){
					return tipo(jogada,tab[lin + parametro/2][col]);
				}else{
					if(tipo(tab[lin + parametro/2][col],tab[lin + parametro][col]) == tipo(jogada,tab[lin + parametro/2][col])){
						return tipo(jogada,tab[lin + parametro/2][col]);
					}else{
						return 3;
					}
				}
			}

		}else{
			
    		if(tipo(jogada,tab[lin][col + parametro]) == 3){
				return 3;
		    }else{
				if(col + 2*parametro == limite || col + parametro == -1){
					return tipo(jogada,tab[lin][col + parametro]);
				}else{
					if(tipo(tab[lin][col + parametro],tab[lin][col + 2*parametro]) == tipo(jogada,tab[lin][col + parametro])){
						return tipo(jogada,tab[lin + parametro/2][col]);
					}else{
						return 3;
					}				
				}
			}
			
		}
	}
}

int juiz(PLAYER *P, int **tab,int lin, int col,int escolha, int count, int imax, int jmax){

  if(count < 7){

		if(escolha < 1 || escolha > 6){
		printf("Escolha um valor valido para a peca\n");
		return 0;
	    } 

		int jogada = P->pecas[escolha - 1]->peca;


		if( lin < 0 || col < 0 || col >= jmax || lin >= imax || tab[lin][col] != 0 ){
			printf("Escolha um lugar valido\n");
			return 0;
		}	

		int alcesq=0,alcbaixo=0,alccima=0,alcdir=0;

		int i=1;
		while( col >= i && tab[lin][col-i] != 0 ){
			if(tab[lin][col-i] == jogada){
				printf("Peca igual na mesma linha\n");
				return 0;
			}
			alcesq++;
			i++;
		}
		i=1;
		while( lin >= i && tab[lin-i][col] != 0){
			if(tab[lin-i][col] == jogada){
				printf("Peca igual na mesma coluna\n");
				return 0;
			}
			alccima++;
			i++;
		}
		i=1;
		while( col + i < jmax && tab[lin][col + i] != 0 ){	
			if(tab[lin][col+i] == jogada){
				printf("Peca igual na mesma linha\n");
				return 0;
			}
			alcdir++;
			i++;	
		}
		i=1;
		while( lin + i < imax && tab[lin+i][col] != 0 ){
			if(tab[lin+i][col] == jogada){
				printf("Peca igual na mesma coluna\n");
				return 0;
			}
			alcbaixo++;
			i++;
		}

		if ( alccima + alcbaixo >= 6 || alcesq + alcdir >= 6 ){
			printf("Linha ou coluna cheia\n");
			return 0;
		}
		
  		int cima = auxiliar(tab,lin,col,imax,alccima,jogada,-2);
		int baixo = auxiliar(tab,lin,col,imax,alcbaixo,jogada,2);
		int esq = auxiliar(tab,lin,col,jmax,alcesq,jogada,-1);
		int dir = auxiliar(tab,lin,col,jmax,alcdir,jogada,1);

		if(cima == 3 || baixo == 3){
			printf("Nao corresponde ao padrao da coluna\n");	
			return 0;
		}else{
			if( (cima != baixo) && (cima * baixo != 0) ){
				printf("Nao corresponde ao padrao da coluna\n");
				return 0;
			}
		}

		if(dir == 3 || esq == 3){
			printf("Nao corresponde ao padrao da linha\n");	
			return 0;
		}else{
			if( (esq != dir) && (esq * dir != 0) ){
				printf("Nao corresponde ao padrao da linha\n");
				return 0;
			}
		}

		i=1;

		if(count > 1){//checar se esta alinhado com primeira jogada

			if(P->pecas[escolha - 1]->estado == 2){
			printf("Peca ja escolhida\n");
			return 0;
			}


			if(lin == P->joglin[0]){

				if(P->jogcol[0] > col){
					
					while(col + i < P->jogcol[0]){
						if( tab[lin][col + i] == 0 ){
							printf("Alinhe-se com as jogadas anteriores\n");
							return 0;
						}
						i++;
					}

				}else{
	
					while(col - i > P->jogcol[0]){
						if( tab[lin][col - i] == 0 ){
							printf("Alinhe-se com as jogadas anteriores\n");
							return 0;
						}
						i++;
					}
				}

				i=1;

				if(count > 2){//checar se esta alinhado com a segunda jogada
					if(P->joglin[1] != lin){
						printf("Alinhe-se com as jogadas anteriores\n");
						return 0;						
					}

					if(P->jogcol[1] > col){
					
						while(col + i < P->jogcol[1]){
							if( tab[lin][col + i] == 0 ){
								printf("Alinhe-se com as jogadas anteriores\n");
								return 0;
							}
							i++;
						}

					}else{
	
						while(col - i > P->jogcol[1]){
							if( tab[lin][col - i] == 0 ){
								printf("Alinhe-se com as jogadas anteriores\n");
								return 0;
							}
							i++;
						}
					}

				}

			}else{
				if(col == P->jogcol[0]){

					if(P->joglin[0] > lin){
					
						while(lin + i < P->joglin[0]){
							if( tab[lin + i][col] == 0 ){
								printf("Alinhe-se com as jogadas anteriores\n");
								return 0;
							}
							i++;
						}

					}else{
	
						while(lin - i > P->joglin[0]){
							if( tab[lin - i][col] == 0 ){
								printf("Alinhe-se com as jogadas anteriores\n");
								return 0;
							}
							i++;
						}
					}

					i=1;

					if(count > 2){//checar se esta alinhado com a segunda jogada
						if(P->jogcol[1] != col){
							printf("Alinhe-se com as jogadas anteriores\n");
							return 0;						
						}

						if(P->joglin[1] > lin){
					
							while(lin + i < P->joglin[1]){
								if( tab[lin + i][col] == 0 ){
									printf("Alinhe-se com as jogadas anteriores\n");
									return 0;
								}
								i++;
							}

						}else{
	
							while(lin - i > P->joglin[1]){
								if( tab[lin - i][col] == 0 ){
									printf("Alinhe-se com as jogadas anteriores\n");
									return 0;
								}
								i++;
							}
						}

					}


				}else{
					printf("Alinhe-se com as jogadas anteriores\n");
					return 0;
				}
			}
		}

	}else{
		int k=0;
		
		while(P->jogcol[k] != -1){
			k++;
		}

		if(k>0){
			if(k==1){

				int cima=0,baixo=0,esq=0,dir=0;
				int i=1;
				while( P->jogcol[0] >= i && tab[P->joglin[0]][P->jogcol[0]-i] != 0 ){
					P->pontos++;
					esq++;
					i++;
				}
				i=1;
				while( P->joglin[0] >= i && tab[P->joglin[0]-i][P->jogcol[0]] != 0){
					P->pontos++;
					cima++;
					i++;
				}
				i=1;
				while( P->jogcol[0] + i < jmax && tab[P->joglin[0]][P->jogcol[0] + i] != 0 ){	
					P->pontos++;
					dir++;
					i++;	
				}
				i=1;
				while( P->joglin[0] + i < imax && tab[P->joglin[0]+i][P->jogcol[0]] != 0 ){
					P->pontos++;
					baixo++;
					i++;
				}
				if(dir > 0|| esq > 0){
					P->pontos++;//contar o proprio quadradinho
				}
				if(cima > 0|| baixo > 0){
					P->pontos++;//contar o proprio quadradinho
				}
				if(cima == 0 && baixo == 0 && dir == 0 && esq == 0){
					P->pontos++;//significa que é a jogada inicial
				}
				if(baixo + cima == 5){
					P->pontos+=6;
				}
				if(esq + dir == 5){
					P->pontos+=6;
				}

			}else{
				int cima=0,baixo=0,esq=0,dir=0;
				if(P->jogcol[0] == P->jogcol[1]){//coluna
					for(int i=0;i<k;i++){
						
						int j=1;
						while( P->jogcol[0] + j < jmax && tab[P->joglin[i]][P->jogcol[0] + j] != 0 ){	
							P->pontos++;
							dir++;
							j++;	
						}

						j=1;
						while( P->jogcol[0] >= j && tab[P->joglin[i]][P->jogcol[0]-j] != 0 ){
							P->pontos++;
							esq++;
							j++;
						}
						if(dir > 0|| esq > 0){
							P->pontos++;//contar o proprio quadradinho
						}
						if(esq + dir == 5){
							P->pontos+=6;
						}
						esq=0;
						dir=0;

					}

					//agora na coluna

					int j=1;
					while( P->joglin[0] >= j && tab[P->joglin[0]-j][P->jogcol[0]] != 0){
						P->pontos++;
						cima++;
						j++;
					}
					j=1;
					while( P->joglin[0] + j < imax && tab[P->joglin[0]+j][P->jogcol[0]] != 0 ){
						P->pontos++;
						baixo++;
						j++;
					}

					P->pontos++;//contar a propria
					if(cima + baixo == 5){
						P->pontos+=6;
					}

				}else{//linha
					for(int i=0;i<k;i++){
						
						int j=1;
						while( P->joglin[0] + j < imax && tab[P->joglin[0]+j][P->jogcol[i]] != 0 ){	
							P->pontos++;
							baixo++;
							j++;	
						}
						
						j=1;
						while( P->joglin[0] >= j && tab[P->joglin[0]-j][P->jogcol[i]] != 0 ){
							P->pontos++;
							cima++;
							j++;
						}
						if(cima > 0|| baixo > 0){
							P->pontos++;//contar o proprio quadradinho
						}
						if(cima + baixo == 5){
							P->pontos+=6;
						}
						cima=0;
						baixo=0;

					}

					//agora na linha

					int j=1;
					while( P->jogcol[0] >= j && tab[P->joglin[0]][P->jogcol[0]-j] != 0){
						P->pontos++;
						esq++;
						j++;
					}
					j=1;
					while( P->jogcol[0] + j < jmax && tab[P->joglin[0]][P->jogcol[0]+ j] != 0 ){
						P->pontos++;
						dir++;
						j++;
					}

					P->pontos++;//contar a propria
					if(esq + dir == 5){
						P->pontos+=6;
					}
					
				}
			}
		}

		for(int i=0;i<6;i++){
			P->jogcol[i]=-1;
			P->joglin[i]=-1;
			if(P->pecas[i]->estado == 2){
				int checa = sacola(P,i+1);//escolhe uma peca nova, muda o estado dela pra 1 e aponta P->peca[i] para tal peca nova
				if(checa == 0){
					break;//se a sacola esta vazia, n faz sentido continuar tentando
				}

			}
		}

	}
	return 1;
}

int main(void)
{
	system("clear");
	int i, j;

	int n;
	int **tab;

	do
	{
		printf("Quantos jogadores :\n");
		scanf("%d", &n);
	} while (n < 1 || n > 18);

	LimpaBuffer();

	PLAYER P[n];
	i = 0;
	while (i < n)
	{
		printf("Escolha o nome do jogador %d: ", i + 1);
		fgets(P[i].nome, 20, stdin);
		i++;
	}

	int cheat;
	do{
		printf("CHEAT MODE?(sim = 1/nao = 0):\n");//---> ignora pecas
		scanf(" %d",&cheat);
	}while(cheat != 1 && cheat != 0);
	

	for (j = 0; j < 3; j++)
	{
		for (i = 0; i < 36; i++)
		{
			pc[i + j * 36].peca = i % 6 + 1 + (i / 6 + 1) * 10;
			pc[i + j * 36].estado = 0;
		}
	}

	int imax = 1, jmax = 1;

	tab = (int **)malloc(sizeof(int *) * imax);
	if (tab == NULL)
	{
		printf("Erro de alocacao\n");
	}

	for (i = 0; i < imax; i++)
	{
		tab[i] = (int *)malloc(sizeof(int) * jmax); 
		if (tab[i] == NULL)
		{
			printf("Erro de alocacao\n");
		}
	}

	for (i = 0; i < imax; i++)
	{
		for (j = 0; j < jmax; j++)
		{
			tab[i][j] = 0;
		}
	}

	for(int k=0;k<n;k++){
		sacola(&(P[k]),0);
	}

	int game = 1;

	while (game == 1)
	{
		for (int k = 0; k < n; k++)
		{	
			char letras[6]="ABCDEF";

			tabela(tab, imax, jmax);

			printf("Jogada de %s\n",P[k].nome);
			if(cheat == 0){
			for(int i=0;i<6;i++){
				if(P[k].pecas[i]->estado != 2){
				printf("%c%d ",letras[(P[k].pecas[i]->peca/10)-1],(P[k].pecas[i]->peca)%10);
				}else{
					printf(" *");
				}
			}printf("\n");
			}else{
				printf("***Cheat mode***\n");
			}
			for(int u =0;u<n;u++){
				printf("Pontuacao de %s ==> %d \n",P[u].nome,P[u].pontos);
			}

			int count = 0;
			char opcao;

			while(count < 6){

				if(count == 0){
					do{
					printf("Opcoes: Trocar (t ou T) [p1 p2 p3 p4 p5 p6] | Jogar (j ou J) na posicao x y | Passar (p ou P)\n");
					scanf(" %c",&opcao);
					}while(opcao != 'j' && opcao != 'J'&& opcao !='t' && opcao != 'T'&& opcao != 'p'&& opcao != 'P');//mudar depois para if
					printf("\n");
				}else{
					do{
					printf("Opcoes: Jogar (j ou J) na posicao x y | Passar (p ou P)\n");
					scanf(" %c",&opcao);
					}while(opcao != 'j' && opcao != 'J'&& opcao != 'p'&& opcao != 'P');
					printf("\n");
				}

				count++;

				if(opcao == 'j' || opcao == 'J'){

						int escolha,lin,col,pode = 1;

						do{
							tabela(tab, imax, jmax);

							if(cheat == 0){
								for(int i=0;i<6;i++){
									if(P[k].pecas[i]->estado != 2){
										printf("%c%d ",letras[(P[k].pecas[i]->peca/10)-1],(P[k].pecas[i]->peca)%10);
									}else{
										printf(" * ");
									}
							
								}
								printf("\n");
								printf("1  2  3  4  5  6\n");
								printf("(caso queira sair, pressione -1 e depois qualquer teclas)\n");
							}else{
								printf("***Cheat mode***\n");
							}
							printf("Escolha a peca");
							if(cheat == 0){
								printf(" (1...6)");
							}
							printf(" e posicao (linha/coluna): ");
							if(cheat == 0){
								scanf("%d %d %d",&escolha ,&lin, &col);
							}else{
								char input[3];
								int jogada;
								LimpaBuffer();
								do{
								scanf("%s\n",input);//ver aqui
								jogada = tradutor(input);
								}while(jogada == 0);

								for(int y=0;y<3;y++){
									if(pc[y*36 + (jogada/10 - 1)*6 + (jogada%10 - 1)].estado != 2 ){
										P[k].pecas[count - 1]=&pc[y*36 + (jogada/10 - 1)*6 + (jogada%10 - 1)];
										break;
									}
								}
								escolha = count;

								scanf("%d %d",&lin,&col);

							}
							printf("\n");

							if(escolha == -1){
								break;
							}
							if(cheat == 0){
							pode= juiz(&(P[k]),tab,lin,col,escolha,count,imax,jmax);
							}else{
								pode= juiz(&(P[k]),tab,lin,col,count,count,imax,jmax);
							}
							

						} while (pode == 0);

						if(escolha != -1){
							
							tab[lin][col] = P[k].pecas[escolha - 1]->peca;
							P[k].pecas[escolha - 1]->estado=2;
							P[k].joglin[count - 1]=lin;
							P[k].jogcol[count - 1]=col;
						

							if (lin + 1 == imax)
							{
							tablinha(&tab, imax, jmax, 1);
							imax++;
							}
							if (lin == 0)
							{
							tablinha(&tab, imax, jmax, 0);
							for(int u=0;u<6;u++){
								if(P[k].joglin[u] != -1){
									P[k].joglin[u]++;
								}
							}
							imax++;
							}
							if (col + 1 == jmax)
							{
							tabcoluna(&tab, imax, jmax, 1);
							jmax++;
							}
							if (col == 0)
							{
							tabcoluna(&tab, imax, jmax, 0);
							for(int u=0;u<6;u++){
								if(P[k].jogcol[u] != -1){
								P[k].jogcol[u]++;
							}
							}
							jmax++;
							}
							tabela(tab, imax, jmax);
						}else{
							break;
						}

			
		    	}else{

			  		if( (opcao == 't' || opcao == 'T') && cheat == 0){

					   for(int i=0;i<6;i++){
						  printf("%c%d ",letras[(P[k].pecas[i]->peca)/10-1],(P[k].pecas[i]->peca)%10);
					   }printf("\n");

					   for(int i=0;i<6;i++){
						   printf("%2d ",i+1);
					   }printf("\n");

					   int totalpecas;
					   do{	
					   printf("Quantas pecas deseja alterar?:\n");
					   scanf("%d",&totalpecas);
					   }while(totalpecas < 1 || totalpecas > 6);

					   printf("Qual(is) peca(s) deseja trocar?:\n");

					   int escolhas[totalpecas];

					   for(int i=0;i<totalpecas;i++){
						   scanf("%d",&escolhas[i]);

						   for(int j =i-1;j>=0;j--){
							   if(escolhas[i] == escolhas[j]){
								   printf("Sem valores repetidos!!!\n");
								   i--;
								   break;
							   }
						   }

						   if(escolhas[i] > 6 || escolhas[i] < 1){
							   printf("Escolha um valor valido!!!\n");//mandar depois checar se escolheu duas vezes
							   i--;
						   }
					   }

					   for(int i=0;i<totalpecas;i++){
						   pca *tmp=P[k].pecas[escolhas[i]-1];//ou é pca *tmp=&(P[k].pecas[escolhas[i]-1]);?
						   int checa = sacola(&(P[k]),escolhas[i]);
						   if(checa == 0){
							  // P[k].pecas[escolhas[i]-1]->estado=1;
							   break;
						   }else{
							   tmp->estado=0;
						   }
					   }
			 		}
					 
					 break;
		    	}

			}
			
			count = 7;
			juiz(&(P[k]),tab,0,0,0,count,imax,jmax);
			int acujogo=0;
			for(int u=0;u<n;u++){
				
				for(int y=0;y<6;y++){
					if(P[u].pecas[y]->estado == 2){
						acujogo++;
					}
				}

			}
			if(acujogo == n*6){
				game = 0;
			}

			if(game == 0){
				int ptsvencedor=0;
				int vencedor;
				for(int u=0;u<n;u++){
					if(P[u].pontos > ptsvencedor){
						vencedor =u;
					}
				}
				printf("Vitoria de %s Com %d pontos!!!",P[vencedor].nome,P[vencedor].pontos);
				break;
			}
			printf("\n*******************************************************\n");
		}//proximo player
	}
}